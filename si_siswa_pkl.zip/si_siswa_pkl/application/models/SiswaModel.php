<?php

class SiswaModel extends CI_Model{
	
	
	function semua(){
			 return $this->db->query('select * from siswa  where not status=3');
	}
	function pending(){
			return $this->db->query('select * from siswa where status=0');
	}
	function terima(){
			return $this->db->query('select * from siswa where status=1');
	}
	function tolak(){
			return $this->db->query('select * from siswa where status=2');
	}
	function input_data($data,$table){
		$this->db->insert($table,$data);
	}
	function edit_data($where,$table){
		return $this->db->get_where($table,$where);
	}
	function update_data($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}
	
	function hapus_data($where,$table){
		$this->db->where($where);
		$this->db->delete($table);
	}	
	public function upload(){
		$nama=$this->input->post('nama');
		$config['upload_path'] = './images/';
		$config['allowed_types'] = 'jpg|png|jpeg';
		$config['max_size']	= '2048';
		$config['remove_space'] = TRUE;
		$config['file_name']=$nama;
	
		$this->load->library('upload', $config); // Load konfigurasi uploadnya
		if($this->upload->do_upload('input_gambar')){ // Lakukan upload dan Cek jika proses upload berhasil
			// Jika berhasil :
			$return = array('result' => 'success', 'file' => $this->upload->data(), 'error' => '');
			return $return;
		}else{
			// Jika gagal :
			$return = array('result' => 'failed', 'file' => '', 'error' => $this->upload->display_errors());
			return $return;
		}
	}
	
	// Fungsi untuk menyimpan data ke database
	public function save($upload){
		$data = array(
		'nisn'=>$this->input->post('nisn'),
		'nama'=>$this->input->post('nama'),
		'jenis_kelamin'=>$this->input->post('jenis_kelamin'),
		'tgl_lahir'=>$this->input->post('tgl_lahir'),
		'alamat'=>$this->input->post('alamat'),
		'telp'=>$this->input->post('telp'),
		'email'=>$this->input->post('email'),
		'asal_sekolah'=>$this->input->post('asal_sekolah'),
		'alamat_sekolah'=>$this->input->post('alamat_sekolah'),
		'jurusan'=>$this->input->post('jurusan'),
		'minat'=>$this->input->post('minat'),
		'kopetensi_keahlian'=>$this->input->post('kopetensi_keahlian'),
		'tgl_mulai_magang'=>$this->input->post('tgl_mulai_magang'),
		'tgl_akhir_magang'=>$this->input->post('tgl_akhir_magang'),
		'foto' => $upload['file']['file_name']
		);
		


if($data == null) {
        $this->session->set_flashdata('msg', 
                '<div class="modal modal-info fade">
                    <h4>Oppss</h4>
                    <p>Tidak ada kata dinput.</p>
                </div>');    
        $this->load->view('welcome_message');      
    } else {    
        $this->session->set_flashdata('msg', 
        '<div class="col-md-14">
          <div class="box box-success box-solid">
            <div class="box-header">
              <b class="box-title">Selamat anda telah terdaftar sebagai calon siswa magang.</b>
             <p></p>
              <p>konfirmasi selanjutnya akan dikirim melalui email, mohon cek secara berkala.</p>
        

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>

            <div class="small-box-footer"></div>
            </div>
            
           
           
          </div>
          
         
        </div>');    
        $this->load->view('welcome_message');    
    };
		$this->db->insert('siswa', $data);
	}
}