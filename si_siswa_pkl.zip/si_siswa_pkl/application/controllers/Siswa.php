<?php


class Siswa extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('SiswaModel');
		$this->load->helper(array('form', 'url'));
		 
	}
	function index(){
		$data['siswa'] = $this->SiswaModel->pending()->result();
		$this->load->view('siswa/index');
	}
	function tambah(){
		$this->load->view('siswa/create2',array('error' => ' ' ));
	}

	function edit1(){
	$email=$this->input->post('email');
	$nama=$this->input->post('nama');
	$minat=$this->input->post('minat');
	$tgl_mulai_magang=$this->input->post('tgl_mulai_magang');
	$tgl_akhir_magang=$this->input->post('tgl_akhir_magang');

	$id=$this->input->post('id');
	$status=$this->input->post('status');
		$data= array(
			'id'=>$id,
		'status'=>'1'
		
	);
	$where = array(
		'id' => $id
	);
	$this->SiswaModel->update_data($where,$data,'siswa');

	//email
	 $config = [
               'mailtype'  => 'html',
               'charset'   => 'utf-8',
               'protocol'  => 'smtp',
               'smtp_host' => 'ssl://smtp.gmail.com',
               'smtp_user' => 'asrsaif04@gmail.com',    // Ganti dengan email gmail kamu
               'smtp_pass' => 'asrsaif04',      // Password gmail kamu
               'smtp_port' => 465,
               'crlf'      => "\r\n",
               'newline'   => "\r\n"
           ];
         // Load library email dan konfigurasinya
        $this->load->library('email', $config);

        // Email dan nama pengirim
        $this->email->from('asrsaif04@gmail.com', 'Dafidea Technocraft');

        // Email penerima
        $this->email->to($email); // Ganti dengan email tujuan kamu

        // Lampiran email, isi dengan url/path file
        $this->email->attach('');

        // Subject email
        $this->email->subject('Konfirmasi Penerimaan Magang di Dafidea Technocraft');

        // Isi email
        $this->email->message("<p>Selamat Pagi, </p>


<p>Dengan ini kami menginformasikan bahwa yang bernama : <b>$nama</b></p>
<br>
<p>dinyatakan DITERIMA magang di Dafidea Technocraft mulai tanggal <b>$tgl_mulai_magang</b> s/d <b>$tgl_akhir_magang</b> Di Divisi <b>$minat</b><p>
<p>Kami tunggu kehadirannya di hari pertama magang pada tanggal <b>$tgl_mulai_magang</b> di kantor Dafidea Technocraft di Perumahan Mastrip P 11 Sumbersari Jember.</p>
<p>Selamat bergabung dengan keluarga kami </p>
<p>Terima kasih.</p>
<br>
<br>
<p><b>Enggal Deny Saputra</b></p>
<p>Internship Manager Dafidea Technocraft</p>
<br>
<p>untuk info lebih lanjut hubungi:</p>
<p><b>0877-5774-7804</b>(Enggal Deny Saputra)</p>");

        // Tampilkan pesan sukses atau error
        if ($this->email->send()) {
            echo 'Sukses! email berhasil dikirim.';
        } else {
            echo 'Error! email tidak dapat dikirim.';
        }
	redirect('admin/data');
	}






function edit1_1(){
	$email=$this->input->post('email');
	$nama=$this->input->post('nama');
	$minat=$this->input->post('minat');
	$tgl_mulai_magang=$this->input->post('tgl_mulai_magang');
	$tgl_akhir_magang=$this->input->post('tgl_akhir_magang');

	$id=$this->input->post('id');
	$status=$this->input->post('status');
		$data= array(
			'id'=>$id,
		'status'=>'1'
		
	);
	$where = array(
		'id' => $id
	);
	$this->SiswaModel->update_data($where,$data,'siswa');

	//email
	 $config = [
               'mailtype'  => 'html',
               'charset'   => 'utf-8',
               'protocol'  => 'smtp',
               'smtp_host' => 'ssl://smtp.gmail.com',
               'smtp_user' => 'asrsaif04@gmail.com',    // Ganti dengan email gmail kamu
               'smtp_pass' => 'asrsaif04',      // Password gmail kamu
               'smtp_port' => 465,
               'crlf'      => "\r\n",
               'newline'   => "\r\n"
           ];
         // Load library email dan konfigurasinya
        $this->load->library('email', $config);

        // Email dan nama pengirim
        $this->email->from('asrsaif04@gmail.com', 'Dafidea Technocraft');

        // Email penerima
        $this->email->to($email); // Ganti dengan email tujuan kamu

        // Lampiran email, isi dengan url/path file
        $this->email->attach('');

        // Subject email
        $this->email->subject('Konfirmasi Penerimaan Magang di Dafidea Technocraft');

        // Isi email
        $this->email->message("<p>Selamat Pagi, </p>


<p>Dengan ini kami menginformasikan bahwa yang bernama : <b>$nama</b></p>
<br>
<p>dinyatakan DITERIMA magang di Dafidea Technocraft mulai tanggal <b>$tgl_mulai_magang</b> s/d <b>$tgl_akhir_magang</b> Di Divisi <b>$minat</b><p>
<p>Kami tunggu kehadirannya di hari pertama magang pada tanggal <b>$tgl_mulai_magang</b> di kantor Dafidea Technocraft di Perumahan Mastrip P 11 Sumbersari Jember.</p>
<p>Selamat bergabung dengan keluarga kami </p>
<p>Terima kasih.</p>
<br>
<br>
<p><b>Enggal Deny Saputra</b></p>
<p>Internship Manager Dafidea Technocraft</p>
<br>
<p>untuk info lebih lanjut hubungi:</p>
<p><b>0877-5774-7804</b>(Enggal Deny Saputra)</p>");

        // Tampilkan pesan sukses atau error
        if ($this->email->send()) {
            echo 'Sukses! email berhasil dikirim.';
        } else {
            echo 'Error! email tidak dapat dikirim.';
        }
	redirect('admin/data');
	}









	function edit2(){
	$email=$this->input->post('email');
	$nama=$this->input->post('nama');
	$id=$this->input->post('id');
	$status=$this->input->post('status');
		$data= array(
			'id'=>$id,
		'status'=>'2'

	);
	$where = array(
		'id' => $id
	);
	//email
	 $config = [
               'mailtype'  => 'html',
               'charset'   => 'utf-8',
               'protocol'  => 'smtp',
               'smtp_host' => 'ssl://smtp.gmail.com',
               'smtp_user' => 'asrsaif04@gmail.com',    // Ganti dengan email gmail kamu
               'smtp_pass' => 'asrsaif04',      // Password gmail kamu
               'smtp_port' => 465,
               'crlf'      => "\r\n",
               'newline'   => "\r\n"
           ];

    $this->SiswaModel->update_data($where,$data,'siswa');
         // Load library email dan konfigurasinya
        $this->load->library('email', $config);

        // Email dan nama pengirim
        $this->email->from('asrsaif04@gmail.com', 'Dafidea Technocraft');

        // Email penerima
        $this->email->to($email); // Ganti dengan email tujuan kamu

        // Lampiran email, isi dengan url/path file
        $this->email->attach('');

        // Subject email
        $this->email->subject('Konfirmasi Penerimaan Magang di Dafidea Technocraft');

        // Isi email
        $this->email->message("<p>Selamat Pagi,</p> 
<br>
<p>Dengan ini kami menginformasikan bahwa yang bernama : <b>$nama</b> </p>
<br>
<p>dinyatakan BELUM DITERIMA magang di Dafidea Technocraft.</p>
<p>Dikarenakan masih adanya siswa magang pada waktu yang bersamaan.</p>
<br>
<p>Kami mengucapkan banyak terimakasih dan mohon maaf yang sebesar besarnya.</p>
<p>Semoga di lain kesempatan kita bisa berkolaborasi.</p>
<br>
<p><b>Hormat Kami.</b></p>
<br>
<br>
<p><h5>Enggal Deny Saputra</h5><p>
<p>Internship Manager Dafidea Technocraft</p>
<br>
<p>untuk info lebih lanjut hubungi:</p>
<p><b>0877-5774-7804</b>(Enggal Deny Saputra)</p>");

        // Tampilkan pesan sukses atau error
        if ($this->email->send()) {
            echo 'Sukses! email berhasil dikirim.';
        } else {
            echo 'Error! email tidak dapat dikirim.';
        }
	
	redirect('admin/data');
	}





	function edit2_1(){
	$email=$this->input->post('email');
	$nama=$this->input->post('nama');
	$id=$this->input->post('id');
	$status=$this->input->post('status');
		$data= array(
			'id'=>$id,
		'status'=>'2'

	);
	$where = array(
		'id' => $id
	);
	//email
	 $config = [
               'mailtype'  => 'html',
               'charset'   => 'utf-8',
               'protocol'  => 'smtp',
               'smtp_host' => 'ssl://smtp.gmail.com',
               'smtp_user' => 'asrsaif04@gmail.com',    // Ganti dengan email gmail kamu
               'smtp_pass' => 'asrsaif04',      // Password gmail kamu
               'smtp_port' => 465,
               'crlf'      => "\r\n",
               'newline'   => "\r\n"
           ];

    $this->SiswaModel->update_data($where,$data,'siswa');
         // Load library email dan konfigurasinya
        $this->load->library('email', $config);

        // Email dan nama pengirim
        $this->email->from('asrsaif04@gmail.com', 'Dafidea Technocraft');

        // Email penerima
        $this->email->to($email); // Ganti dengan email tujuan kamu

        // Lampiran email, isi dengan url/path file
        $this->email->attach('');

        // Subject email
        $this->email->subject('Konfirmasi Penerimaan Magang di Dafidea Technocraft');

        // Isi email
        $this->email->message("<p>Selamat Pagi,</p> 
<br>
<p>Dengan ini kami menginformasikan bahwa yang bernama : <b>$nama</b> </p>
<br>
<p>dinyatakan BELUM DITERIMA magang di Dafidea Technocraft.</p>
<p>Dikarenakan masih adanya siswa magang pada waktu yang bersamaan.</p>
<br>
<p>Kami mengucapkan banyak terimakasih dan mohon maaf yang sebesar besarnya.</p>
<p>Semoga di lain kesempatan kita bisa berkolaborasi.</p>
<br>
<p><b>Hormat Kami.</b></p>
<br>
<br>
<p><h5>Enggal Deny Saputra</h5><p>
<p>Internship Manager Dafidea Technocraft</p>
<br>
<p>untuk info lebih lanjut hubungi:</p>
<p><b>0877-5774-7804</b>(Enggal Deny Saputra)</p>");

        // Tampilkan pesan sukses atau error
        if ($this->email->send()) {
            echo 'Sukses! email berhasil dikirim.';
        } else {
            echo 'Error! email tidak dapat dikirim.';
        }
	
	redirect('admin/data');
	}





	function edit3($id){
	
	$status=$this->input->post('status');
		$data= array(
			
		'status'=>'3'
	);
	$where = array(
		'id' => $id
	);
	$this->SiswaModel->update_data($where,$data,'siswa');
	redirect('admin/data');
	}



	function tambah_aksi(){
		$nisn=$this->input->post('nisn');
		$nama=$this->input->post('nama');
		$jenis_kelamin=$this->input->post('jenis_kelamin');
		$tgl_lahir=$this->input->post('tgl_lahir');
		$alamat=$this->input->post('alamat');
		$telp=$this->input->post('telp');
		$email=$this->input->post('email');
		$asal_sekolah=$this->input->post('asal_sekolah');
		$alamat_sekolah=$this->input->post('alamat_sekolah');
		$jurusan=$this->input->post('jurusan');
		$minat=$this->input->post('minat');
		$kopetensi_keahlian=$this->input->post('kopetensi_keahlian');
		$tgl_mulai_magang=$this->input->post('tgl_mulai_magang');
		$tgl_akhir_magang=$this->input->post('tgl_akhir_magang');
		
		
		
		$data= array(
		'nisn'=>$nisn,
		'nama'=>$nama,
		'jenis_kelamin'=>$jenis_kelamin,
		'tgl_lahir'=>$tgl_lahir,
		'alamat'=>$alamat,
		'telp'=>$telp,
		'email'=>$email,
		'asal_sekolah'=>$asal_sekolah,
		'alamat_sekolah'=>$alamat_sekolah,
		'jurusan'=>$jurusan,
		'minat'=>$minat,
		'kopetensi_keahlian'=>$kopetensi_keahlian,
		'tgl_mulai_magang'=>$tgl_mulai_magang,
		'tgl_akhir_magang'=>$tgl_akhir_magang
		
		
		
		);
		$this->SiswaModel->input_data($data,'siswa');
		redirect('siswa/index');
	}
	function edit($id){
		$where= array ('id'=>$id);
		$data['siswa']=$this->SiswaModel->edit_data($where,'siswa')->result();
		$this->load->view('update',$data);
	}
	function update(){
	$id = $this->input->post('id');
	$nisn=$this->input->post('nisn');
		$nama=$this->input->post('nama');
		$jenis_kelamin=$this->input->post('jenis_kelamin');
		$tgl_lahir=$this->input->post('tgl_lahir');
		$alamat=$this->input->post('alamat');
		$telp=$this->input->post('telp');
		$email=$this->input->post('email');
		$asal_sekolah=$this->input->post('asal_sekolah');
		$alamat_sekolah=$this->input->post('alamat_sekolah');
		$jurusan=$this->input->post('jurusan');
		$minat=$this->input->post('minat');
		$kopetensi_keahlian=$this->input->post('kopetensi_keahlian');
		$tgl_mulai_magang=$this->input->post('tgl_mulai_magang');
		$tgl_akhir_magang=$this->input->post('tgl_akhir_magang');
		
		
		$data= array(
		'nisn'=>$nisn,
		'nama'=>$nama,
		'jenis_kelamin'=>$jenis_kelamin,
		'tgl_lahir'=>$tgl_lahir,
		'alamat'=>$alamat,
		'telp'=>$telp,
		'email'=>$email,
		'asal_sekolah'=>$asal_sekolah,
		'alamat_sekolah'=>$alamat_sekolah,
		'jurusan'=>$jurusan,
		'minat'=>$minat,
		'kopetensi_keahlian'=>$kopetensi_keahlian,
		'tgl_mulai_magang'=>$tgl_mulai_magang,
		'tgl_akhir_magang'=>$tgl_akhir_magang
	);

	$where = array(
		'id' => $id
	);

	$this->SiswaModel->update_data($where,$data,'siswa');
	redirect('crud/index');
	}
	function hapus($id){
		$where = array ('id'=>$id);
		$this->SiswaModel->hapus_data($where,'siswa');
		redirect('admin/data');
	}
	public function tambah_gambar(){
		$data = array();
		
		if($this->input->post('submit')){ // Jika user menekan tombol Submit (Simpan) pada form
			// lakukan upload file dengan memanggil function upload yang ada di GambarModel.php
			$upload = $this->SiswaModel->upload();
			
			if($upload['result'] == "success"){ // Jika proses upload sukses
				 // Panggil function save yang ada di GambarModel.php untuk menyimpan data ke database
				$this->SiswaModel->save($upload);
				
				redirect('siswa'); // Redirect kembali ke halaman awal / halaman view data
			}else{ // Jika proses upload gagal
				$data['message'] = $upload['error']; // Ambil pesan error uploadnya untuk dikirim ke file form dan ditampilkan
			}
		}
		
		$this->load->view('siswa/create2', $data);
	}
	
}





