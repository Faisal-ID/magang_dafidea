<?php
 
class Admin extends CI_Controller{
 
    function __construct(){
        parent::__construct();     
        $this->load->model('LoginModel');
		 $this->load->model('SiswaModel');
		if(empty($this->session->userdata('status'))){
			 redirect('login');
		 }
	}

    function index(){
    	$data['semua'] = $this->SiswaModel->semua()->num_rows();
    	$data['pending'] = $this->SiswaModel->pending()->num_rows();
    	$data['terima'] = $this->SiswaModel->terima()->num_rows();
    	$data['tolak'] = $this->SiswaModel->tolak()->num_rows();
		$data['siswa'] = $this->SiswaModel->pending()->result();

		$this->load->view('admin/index',$data);	
	}

	function data(){
		$data['siswa'] = $this->SiswaModel->semua()->result();
		$this->load->view('admin/index2',$data);	
	}
	
	function salah(){
		$this->load->view('login/salah');
	}
 
    
 
    function logout(){
        $this->session->sess_destroy();
        redirect(base_url('login'));
    }
	 
}