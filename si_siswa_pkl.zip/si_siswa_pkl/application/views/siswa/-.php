<!DOCTYPE html>
<html>
<head>
	<title>Membuat CRUD dengan CodeIgniter | MalasNgoding.com</title>
</head>
<body>
	<center><h1>Membuat CRUD dengan CodeIgniter | MalasNgoding.com</h1></center>
	<center><?php echo anchor('Siswa/tambah','Tambah Data'); ?></center>
	<table style="margin:20px auto;" border="1">
		<tr>
			<th>No</th>
			<th>Nama</th>
			<th>Alamat</th>
			<th>Pekerjaan</th>
			<th>Action</th>
		</tr>
		<?php 
		$no = 1;
		foreach($siswa as $u){ 
		?>
		<tr>
			<td>USR00<?php echo $no++ ?></td>
			<td><?php echo $u->nisn ?></td>
			<td><?php echo $u->nama ?></td>
			<td><?php echo $u->jenis_kelamin ?></td>
			<td><?php echo $u->tgl_lahir ?></td>
			<td><?php echo $u->alamat ?></td>
			<td><?php echo $u->telp ?></td>
			<td><?php echo $u->email ?></td>
			<td><?php echo $u->asal_sekolah ?></td>
			<td><?php echo $u->alamat_sekolah ?></td>
			<td><?php echo $u->jurusan ?></td>
			<td><?php echo $u->minat ?></td>
			<td><?php echo $u->kopetensi_keahlian ?></td>
			<td><?php echo $u->tgl_mulai_magang ?></td>
			<td><?php echo $u->tgl_akhir_magang ?></td>
			
			<td>
			      <?php echo anchor('Siswa/edit/'.$u->id,'Edit'); ?>
                              <?php echo anchor('Siswa/hapus/'.$u->id,'Hapus'); ?>
			</td>
		</tr>
		<?php } ?>
	</table>
</body>
</html>