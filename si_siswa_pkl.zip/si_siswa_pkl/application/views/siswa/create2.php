<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Dafidea Technocraft</title>
  <!-- Tell the browser to be responsive to screen wnameth -->
  <meta content="wnameth=device-wnameth, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo base_url('assets/bower_components/bootstrap/dist/css/bootstrap.min.css')?>">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url('assets/bower_components/font-awesome/css/font-awesome.min.css')?>">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo base_url('assets/bower_components/Ionicons/css/ionicons.min.css')?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url('assets/dist/css/AdminLTE.min.css')?>">
  <!-- iCheck -->
  <link rel="stylesheet"  href="<?php echo base_url('assets/plugins/iCheck/square/blue.css')?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/dist/css/skins/_all-skins.min.css')?>">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"><style type="text/css">

</style>



 <style>
    .example-modal .modal {
      position: relative;
      top: auto;
      bottom: auto;
      right: auto;
      left: auto;
      display: block;
      z-index: 1;
    }

    .example-modal .modal {
      background: transparent !important;
    }
  </style></head>
<body class="hold-transition login-page">

  <div class="login-logo">
   
 <b>Form </b>Pendaftaran</a>
  <a>Siswa <b>Magang</b>
  </div>
  <!-- /.login-logo -->

    <div class="col-sm-3">
</div>
    <div class="col-sm-6">
          <!-- Horizontal Form -->
          <div class="box box-info">
           
            <!-- /.box-header -->
           


         
		  
		 
		  
		  <form class="form-horizontal"  action="tambah_gambar" method="post" enctype="multipart/form-data" role="form" id="formfield" onsubmit="return validateForm();">
         <input type="hidden" name="action" value="add_form" />
		  <div class="login-box-body">
	
		 <div class="form-group">
                  <label  class="col-sm-2 control-label">NISN</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="nisn"id="nisn" placeholder="0123456789001" required="">
                  </div>
                </div>
               <div class="form-group">
			   
                  <label  class="col-sm-2 control-label">Nama</label>
                  <div class="col-sm-10">
				
                    <input type="text" class="form-control" name="nama" id="nama" placeholder="Nama Lengkap" required="">

                  </div>
                </div>
				 <div class="form-group">
                  <label class="col-sm-2 control-label" for="jenis_kelamin">Jenis Kelamin</label>
                  <div class="col-sm-3">
				   <label>
                    <input type="radio"  name="jenis_kelamin" id="jenis_kelamin1" value="Laki Laki" required="" >
					Laki-Laki
					</label>

				
                  </div>
                   <div class="col-sm-3">
          
          <label>
                    <input type="radio"  name="jenis_kelamin" id="jenis_kelamin2" value="Perempuan" required="" >
          Perempuan
          </label>
                  </div>
                </div>
				 <div class="form-group">
                  <label class="col-sm-2 control-label">Tanggal Lahir</label>
                  <div class="col-sm-10">
                    <input type="date" class="form-control" name="tgl_lahir" id="tgl_lahir" placeholder="yyyy-mm-dd" required="">
                  </div>
                </div>
				
				<div class="form-group">
                  <label  class="col-sm-2 control-label">Alamat</label>
                 
				  <div class="col-sm-10">
                     <textarea name="alamat" class="form-control" id="alamat" rows="3" placeholder="Jalan, no rumah, Desa, Kecamatan, Kabupaten, Kode Pos " required=""></textarea>
                  </div>
                </div>
				 <div class="form-group">
                  <label class="col-sm-2 control-label">No Telp</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="telp" id="telp" placeholder="08-- ---- ----" required="" >


                  </div>
                </div>


				 <div class="form-group">
                  <label  class="col-sm-2 control-label">Email</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="email" id="email" placeholder="example@gmail.com" required="">
                  </div>
                </div>
				 <div class="form-group">
                  <label  class="col-sm-2 control-label">Asal Sekolah</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="asal_sekolah" id="asal_sekolah" placeholder="Asal Sekolah" required="">
                  </div>
                </div>
				 <div class="form-group">
                  <label  class="col-sm-2 control-label">Alamat Sekolah</label>
               				  <div class="col-sm-10">
                     <textarea name="alamat_sekolah" id="alamat_sekolah" class="form-control" rows="3" placeholder="Jalan, No Gedung, Desa, Kecamatan, Kabupaten Kode Pos" required=""></textarea>
                  </div>
                </div>
				 <div class="form-group">
                  <label class="col-sm-2 control-label">Jurusan</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="jurusan" id="jurusan" placeholder="RPL/Multimedia" required="">
                  </div>
                </div>


				 <div class="form-group">
                  <label class="col-sm-2 control-label">Minat</label>
         <div class="col-sm-2">
           <label>
                    <input type="radio"  name="minat" id="minat1" value="Designer"  required="" > Designer
          </label>
        </div>
                   <div class="col-sm-3">
          
          <label>
                    <input type="radio"  name="minat" id="minat2" value="Programer" required=""  >Programer
          </label>
                  </div>
                </div>
				
				
				
				
				
				
				 <div class="form-group">
                  <label  class="col-sm-2 control-label">Kopetensi Keahlian</label>
                  <div class="col-sm-10">
                     <textarea name="kopetensi_keahlian" id="kopetensi_keahlian" class="form-control" rows="3" placeholder="Membuat Web Dinamis, Basisdata, Bahasa Pemrograman PHP,C, Java.
Membuat wpap, edit video dan foto, vector dll." required=""></textarea>
                  </div>
                </div>
				 <div class="form-group">
                  <label class="col-sm-2 control-label">Tanggal Mulai Magang </label>
                  <div class="col-sm-10">
                    <input type="date" class="form-control" name="tgl_mulai_magang" id="tgl_mulai_magang" placeholder="yyyy-mm-dd" required="">
                  </div>
                </div>
				
				
				
			
				
				
				 <div class="form-group">
                  <label  class="col-sm-2 control-label">Tanggal Akhir Magang</label>
                  <div class="col-sm-10">
                    <input type="date" class="form-control" name="tgl_akhir_magang" id="tgl_akhir_magang" placeholder="yyyy-mm-dd" required="">
                    <div class="div_image"></div>
                  </div>
                </div>
				
				 <div class="form-group">
                  <label  class="col-sm-2 control-label">Foto</label>
                  <div class="col-sm-10">
                    <input type="file"  name="input_gambar" id="file_gambar" required="">
                   

                     <p class="help-block">*Gambar Harus Resmi Dari Sekolah</p>
                     <input type="hidden"  name="status" value="0">
                  </div>
                </div>
					
					  <div class="box-footer">
               
				
          <input type="button" name="btn" value="Kirim" id="submitBtn" data-toggle="modal" data-target="#confirm-submit" class="btn btn-info pull-right">
                
              </button>
              </div>
					
					
					

       <div class="modal fade" id="confirm-submit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Default Modal</h4>
              </div>
              <table class="table">
                    <tr>
                        <th>nisn</th>
                        <td id="1"> </td>
                    </tr>
                    <tr>
                        <th>Nama</th>
                        <td id="2" ></td>
                    </tr>
                    <tr>
                        <th>Jenis Kelamin</th>
                        <td id="3"> </td>
                    </tr>
                    <tr>
                        <th>Tanggal Lahir</th>
                        <td id="4"></td>
                    </tr>
                    <tr>
                        <th>Alamat</th>
                        <td id="5" > </td>
                    </tr>
                    <tr>
                        <th>No Telp</th>
                        <td id="6"></td>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <td id="7"> </td>
                    </tr>
                    <tr>
                        <th>Asal Sekolah</th>
                        <td id="8"></td>
                    </tr>
                     <tr>
                        <th>Alamat Sekolah</th>
                        <td id="9"></td>
                    </tr>
                     <tr>
                        <th>Jurusan</th>
                        <td id="10" ></td>
                    </tr>
                     <tr>
                        <th>Minat</th>
                        <td id="11"></td>
                         
                    </tr>
                     <tr>
                        <th>Kopetensi Keahlian</th>
                        <td id="12"></td>
                    </tr>
                     <tr>
                        <th>Tanggal Mulai Magang</th>
                        <td id="13" ></td>
                    </tr>
                    <tr>
                        <th>Tanggal Akhir Magang</th>
                        <td id="14" ></td>
                    </tr>
                    <tr>
                        <th>Foto</th>
                        <td > <img id="prev_foto" width="200px" src="" class="img-thumbnail"></td>
                    </tr>
                </table>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <input type="submit" name="submit" value="Simpan"  class="btn btn-info pull-right">
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
				


                 
			
       
		
	
	
	


</form>


 </div>





<script src="<?php echo base_url('assets/bower_components/jquery/dist/jquery.min.js')?>"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo base_url('assets/bower_components/bootstrap/dist/js/bootstrap.min.js')?>"></script>
<!-- iCheck -->
<script src="<?php echo base_url('assets/plugins/iCheck/icheck.min.js')?>"></script>


<script src="<?php echo base_url('assets/bower_components/jquery/dist/jquery.min.js')?>"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo base_url ('assets/bower_components/bootstrap/dist/js/bootstrap.min.js')?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url ('assets/bower_components/fastclick/lib/fastclick.js')?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url ('assets/dist/js/adminlte.min.js')?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url ('assets/dist/js/demo.js')?>"></script>
<script>
function readURL(input) {

   if (input.files && input.files[0]) {

    var reader = new FileReader();

     

    reader.onload = function (e) {

     $('#prev_foto').attr('src', e.target.result);

    }

     

    reader.readAsDataURL(input.files[0]);

   }
  }


  $(document).ready(function(){

   $('#file_gambar').change(function(){

     readURL(this);

   });

  });

$('#submitBtn').click(function() {
  if ($('#jenis_kelamin1').is(':checked')==true){
    $('#3').text($('#jenis_kelamin1').val());
  }else if ($('#jenis_kelamin2').is(':checked')==true){
    $('#3').text($('#jenis_kelamin2').val());
  }



  if ($('#minat1').is(':checked')==true){
    $('#11').text($('#minat1').val());
  }else if ($('#minat2').is(':checked')==true){
    $('#11').text($('#minat2').val());
  }
  $('#1').text($('#nisn').val());
  $('#2').text($('#nama').val());

  $('#4').text($('#tgl_lahir').val());
  $('#5').text($('#alamat').val());
  $('#6').text($('#telp').val());
  $('#7').text($('#email').val());
  $('#8').text($('#asal_sekolah').val());
  $('#9').text($('#alamat_sekolah').val());
  $('#10').text($('#jurusan').val());
 
  $('#12').text($('#kopetensi_keahlian').val());
  $('#13').text($('#tgl_mulai_magang').val());
  $('#14').text($('#tgl_akhir_magang').val());


  

});

$('#submit').click(function() {
  alert('submitting');
  $('#formfield').submit();
});


</script>

</body>
</html>

