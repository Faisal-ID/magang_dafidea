<!-- Faisal_ID & AdminASR -->
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Dafidea | Pendaftaran siswa magang</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo base_url('assets/bower_components/bootstrap/dist/css/bootstrap.min.css')?>">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url('assets/bower_components/font-awesome/css/font-awesome.min.css')?>">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo base_url('assets/bower_components/Ionicons/css/ionicons.min.css')?>">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo base_url('assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url('assets/dist/css/AdminLTE.min.css')?>">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo base_url('assets/dist/css/skins/_all-skins.min.css')?>">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">

</head>
<body class="hold-transition skin-blue layout-top-nav">
<div class="wrapper">

  <header class="main-header">
    <nav class="navbar navbar-static-top">
      <div class="container">
        <div class="navbar-header">
      <div class="navbar-custom-menu">
          <ul class="nav navbar-nav">
            <!-- User Account Menu -->
            <li class="dropdown user user-menu">
              <!-- Menu Toggle Button -->
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                <!-- The user image in the navbar-->
                <img src="<?php echo base_url('assets/dist/img/dt.jpg')?>" class="user-image" alt="User Image">
                
                 <span class="logo-lg"><b>"Bangun Softwaremu Dengan Cinta".  </b></span><li><a href="https://goo.gl/maps/kAvHiGV2tkH2"><span class="logo-lg"><i class="fa fa-map-marker"></i> : Perumahan Mastrip P11 Jalan Mastrip Krajan Barat, Krajan Timur, Sumbersari, Kabupaten Jember, Jawa Timur 68121</span></a></li>
              </a>
            </li>
          </ul>
        </div>
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
            <i class="fa fa-bars"></i>
          </button>
        </div>
      </div>
      <!-- /.container-fluid -->
    </nav>
  </header>
  <!-- Full Width Column -->
  <div class="content-wrapper">
    <div class="container">
      <!-- Content Header (Page header) -->

      <section class="content-header">
        <div id="notifications" ><?php echo $this->session->flashdata('msg'); ?></div>
        <h2>
         Dafidea Technocraft
        </h2>
      
      </section>

      <!-- Main content -->
      <section class="content">
        <div class="callout callout-info">
          <h4>Selamat datang di halaman web <b>Dafidea Technocraft</b></h4>

          <p>Dafidea Technocraft merupakan salah satu software house yang ada di Indonesia, yaitu perusahaan yang bergerak dalam bidang pembuatan aplikasi perangkat lunak sesuai dengan kebutuhan perusahaan atau perorangan. Perusahaan ini berpusat di Kabupaten Jember, Jawa Timur.
          Pengembangan software yang saat ini dikembangkan berupa Web Application ( Aplikasi berbasis Web ) dan Dekstop Appication (Aplikasi berbasis Dekstop).</p>
          <p>Dafidea Technocraft juga menerima siswa PKL(Praktek Kerja Lapangan), disini terdapat dua bidang keahlian yaitu sebagai Programer, dan Designer.
          Bagi siswa yang ingin mendaftar silahkan klik tombol daftar di bawah ini!!. 
                   </p>
        </div>
         <a href="<?php echo base_url('Siswa/tambah'); ?>" class="btn btn-primary btn-lg">DAFTAR <i class="fa fa-user-plus"></i></a>
      </section>
      <!-- /.content -->
    </div>
    <!-- /.container -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="container">
    <div class="pull-right hidden-xs">
      <b>by</b> ASR
    </div>
    <strong>Copyright <a href="https://Dafidea.com">Dafidea Technocraft</a>.</strong> 
  </div>
  </footer>
</div>








<!-- jQuery 3 -->
<script src="<?php echo base_url('assets/bower_components/jquery/dist/jquery.min.js')?>"></script>
<!-- Bootstrap 3.3.7 -->
<script src=<?php echo base_url('assets/bower_components/bootstrap/dist/js/bootstrap.min.js')?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url('assets/bower_components/datatables.net/js/jquery.dataTables.min.js')?>"></script>
<script src="<?php echo base_url('assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url('assets/bower_components/jquery-slimscroll/jquery.slimscroll.min.js')?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url('assets/bower_components/fastclick/lib/fastclick.js')?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/dist/js/adminlte.min.js')?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url('assets/dist/js/demo.js')?>"></script>


<!-- page script -->
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })

  })

</script>
</body>
</html>
