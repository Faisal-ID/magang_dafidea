<?php include "header.php"?>

    <!-- Main content -->
      <section class="content">
        <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $semua ?></h3>

              <p>Total</p>
            </div>
            <div class="icon">
              <i class="fa fa-users"></i>
            </div>
            <div class="small-box-footer"></div>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3><?php echo $terima ?></h3>

              <p>Diterima</p>
            </div>
            <div class="icon">
              <i class="fa fa-check-square-o"></i>
            </div>
           <div class="small-box-footer"></div>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3><?php echo $pending ?></h3>

              <p>Pending</p>
            </div>
            <div class="icon">
              <i class="fa fa-exclamation-circle"></i>
            </div>
            <div class="small-box-footer"></div>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3><?php echo $tolak ?></h3>

              <p>Ditolak</p>
            </div>
            <div class="icon">
              <i class="fa fa-close"></i>
            </div>
            <div class="small-box-footer"></div>
          </div>
        </div>
        <!-- ./col -->
      </div>
      <!-- /.row -->
      <h2 class="page-header">Siswa Yang Belum Dikonfirmasi :</h2>
      <div class="row">
 		<?php 
		foreach($siswa as $u){ 
		?>


 <div class="col-md-4">
          <!-- Widget: user widget style 1 -->
          <div class="box box-widget widget-user-2">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header btn-warning">
              <table>
                
                <tr>
                 <td rowspan="4"><img class="img-circle" src="<?php echo base_url('images/'. $u->foto)?>" width="75px" height="75px" ></td>
                </tr>
                <tr>
                  <td><div class="col-sm-1"></div><b><?php echo $u->nama ?></b></td>
                </tr>
                <tr>
                  <td><div class="col-sm-1"></div><?php echo $u->asal_sekolah ?> / <?php echo $u->jurusan ?></td>
                </tr>
                 <tr>
                  <td><div class="col-sm-1"></div><?php echo $u->minat ?></td>
                </tr>
              </table>
              
              <!-- /.widget-user-image -->
              
              
            </div>
            <div class="box-footer no-padding">
              <ul class="nav nav-stacked">
                <center><b>Kompetensi Keahlian</b></center>
               <center><span><?php echo $u->kopetensi_keahlian ?></span>
                </center>
                


                <button type="button" class="btn btn-primary btn-block btn-sm" data-toggle="modal" data-target="#modal-info" onclick="tampildata('<?php echo $u->id ?>', '<?php echo $u->nisn ?>', '<?php echo $u->nama ?>', '<?php echo $u->jenis_kelamin ?>', '<?php echo $u->tgl_lahir ?>', '<?php echo $u->alamat ?>', '<?php echo $u->telp ?>', '<?php echo $u->email ?>', '<?php echo $u->asal_sekolah ?>', '<?php echo $u->alamat_sekolah ?>', '<?php echo $u->jurusan ?>', '<?php echo $u->minat ?>', '<?php echo $u->kopetensi_keahlian ?>', '<?php echo $u->tgl_mulai_magang ?>', '<?php echo $u->tgl_akhir_magang ?>', '<?php echo $u->foto ?>')"><i class="fa fa-info-circle"> Detail</i></button>
               
              </ul>
            </div>
          </div>
          <!-- /.widget-user -->
        </div>


     
        <!-- /.col -->
<?php } ?>
    </div>
    <div class="modal modal-info fade" id="modal-info" >
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Detail Calon Siswa Magang</h4>
              </div>
              <div class="modal-body box-header">
              

<table>
<tr >
<td rowspan="6"><img src="" id="val_foto" width="125px" height="125px" ></td>
</tr>

<tr>
<td> <div class="col-sm-1"></div><b>NISN </b></td>
<td> : <span id="val_nisn"></span></td>
</tr>
<tr>
<td><div class="col-sm-1"></div><b>Nama / JK </b></td>
<td> : <span id="val_nama"></span> / <span id="val_jenis_kelamin"></span></td>
</tr>
<tr>
<td><div class="col-sm-1"></div><b>Tgl Lahir </b></td>
<td> : <span id="val_tgl_lahir"></span></td>
</tr>
<tr>
<td><div class="col-sm-1"></div><b>Alamat </b></td>
<td> : <span id="val_alamat"></span></td>
</tr>
<tr>
<td><div class="col-sm-1"></div><b>Tlp / Email </b></td>
<td> : <span id="val_telp"></span> / <span id="val_email"></span></td>
</tr>
</table>
<br>
<table>
<tr>
<td><b>Asal Sekolah</b></td>
<td> : <span id="val_asal_sekolah"></span></td>
</tr>
<tr>
<td><b>Alamat Sekolah</b></td>
<td> : <span id="val_alamat_sekolah"></span></td>
</tr>
<tr>
  <td><b>Jurusan</b></td>
<td> : <span id="val_jurusan"></span></td>
</tr>
<tr>
<td><b>Minat</b></td>
<td> : <span id="val_minat"></span></td>
</tr>
<tr>
<td><b>Kompetensi Keahlian</b></td>
<td> : <span id="val_kopetensi"</></td>
</tr>
<tr>
<td><b>Lama Magang</b></td>
<td> : <span id="val_tgl_mulai"></span> s/d <span id="val_tgl_akhir"></span></td>
</tr>
</table>










              </div>
              <div class="modal-footer" >
                <div class="col-sm-8"></div>
              
              <div class="col-sm-2">
                <form action="../siswa/edit2_1" method="post">
                  <input type="hidden" name="id" id="val_id_siswa2">
                  <input type="hidden" name="email" id="val_email3">
                   <input type="hidden" name="nama" id="val_nama1">
                  <button type="submit" class="btn btn-danger pull-right"><i class="fa fa-close"> Tolak </i></button>
                </form>
              </div>
               <div class="col-sm-2">
                <form action="../siswa/edit1_1" method="post">
                  <input type="hidden" name="id" id="val_id_siswa1">
                  <input type="hidden" name="email" id="val_email2">
                  <input type="hidden" name="nama" id="val_nama2">
                  <input type="hidden" name="tgl_mulai_magang" id="val_tgl_mulai1">
                  <input type="hidden" name="tgl_akhir_magang" id="val_tgl_akhir1">
                  <input type="hidden" name="minat" id="val_minat1">

                  <!-- email -->

                  <button type="submit" class="btn btn-success pull-right"><i class="fa fa-check-square-o"> Terima </i></button>
                </form>
              </div>
               </div>


            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>


      </section>

  
      <!-- /.content -->
      <script>
    function tampildata(id, nisn, nama, jenis_kelamin, tgl_lahir, alamat, telp, email, asal_sekolah, alamat_sekolah, jurusan, minat, kopetensi_keahlian, tgl_mulai_magang, tgl_akhir_magang, foto){
      $('#val_id_siswa1').val(id);
      $('#val_id_siswa2').val(id);
      $('#val_nisn').html(nisn);
      $('#val_nama').html(nama);
       $('#val_nama1').val(nama);
        $('#val_nama2').val(nama);
      $('#val_jenis_kelamin').html(jenis_kelamin);
      $('#val_tgl_lahir').html(tgl_lahir);
      $('#val_alamat').html(alamat);
      $('#val_telp').html(telp);
      $('#val_email').html(email);
       $('#val_email2').val(email);
        $('#val_email3').val(email);
      $('#val_asal_sekolah').html(asal_sekolah);
      $('#val_alamat_sekolah').html(alamat_sekolah);
      $('#val_jurusan').html(jurusan);
      $('#val_minat').html(minat);
      $('#val_minat1').val(minat);
      $('#val_kopetensi').html(kopetensi_keahlian);
      $('#val_tgl_mulai').html(tgl_mulai_magang);
      $('#val_tgl_mulai1').val(tgl_mulai_magang);
      $('#val_tgl_akhir').html(tgl_akhir_magang);
      $('#val_tgl_akhir1').val(tgl_akhir_magang);
      $('#val_foto').attr('src', '../images/'+foto);
    }
  </script>
  <?php include "footer.php"?>