<?php include "header.php"?>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Data siswa yang mendaftar</h3>
            </div>
            <!-- /.box-header -->

            <div class="box-body">
              <table id="example1" class="table table-bordered  table-hover">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Nisn</th>
                  <th>Nama</th>
				          <th>Asal Sekolah</th>
                  <th>Jurusan</th>
				          <th>Minat</th>
                  <th>Status</th>
                  <th>action</th>
                </tr>
                </thead>
                <tbody>
                <?php 
                $n=1;
		foreach($siswa as $u){ 
		?>
		<tr>
			<td><?php echo $n++ ?></td>
      <td><?php echo $u->nisn ?></td>
			<td><?php echo $u->nama ?></td>hidden
			<td><?php echo $u->asal_sekolah ?></td>
			<td><?php echo $u->jurusan ?></td>
			<td><?php echo $u->minat ?></td>
      <td><?php if($u->status==0){echo '<small class="label bg-yellow"> <i class="fa fa-exclamation-circle"></i></small>';
    }elseif($u->status==1){echo '<small class="label bg-green">  <i class="fa fa-check-square-o"></i></small>';
    }elseif($u->status==2){echo '<small class="label bg-red"><i class="fa fa-close"></i></small>';} ?></td>
			<td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-info" onclick="tampildata('<?php echo $u->id ?>', '<?php echo $u->nisn ?>', '<?php echo $u->nama ?>', '<?php echo $u->jenis_kelamin ?>', '<?php echo $u->tgl_lahir ?>', '<?php echo $u->alamat ?>', '<?php echo $u->telp ?>', '<?php echo $u->email ?>', '<?php echo $u->asal_sekolah ?>', '<?php echo $u->alamat_sekolah ?>', '<?php echo $u->jurusan ?>', '<?php echo $u->minat ?>', '<?php echo $u->kopetensi_keahlian ?>', '<?php echo $u->tgl_mulai_magang ?>', '<?php echo $u->tgl_akhir_magang ?>', '<?php echo $u->foto ?>')"><i class="fa fa-info-circle"> Detail</i></button>
      <?php echo anchor('siswa/edit3/'.$u->id,'<button class="btn btn-danger"><i class="glyphicon glyphicon-trash"> Hapus</i></button>'); ?></td>
		</tr>

   


		<?php } ?>
                </tbody>
                <tfoot>
                <tr>
                  <th>No</th>
                  <th>Nisn</th>
                  <th>Nama</th>
                  <th>Asal Sekolah</th>
				          <th>Alamat Sekolah</th>
                  <th>Jurusan</th>
				          <th>Minat</th>
                  <th>action</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

 <div class="modal modal-info fade" id="modal-info" >
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Detail Calon Siswa Magang</h4>
              </div>
              <div class="modal-body box-header">
              

<table  width="100%">
<tr >
<td rowspan="6"><div class="col-sm-1"></div><img src="" id="val_foto" width="150px" height="150px"></td>
<tr>
<td><b>NISN </b></td>
<td> : <span id="val_nisn"></span></td>
</tr>
<tr>
<td><b>Nama / JK </b></td>
<td> : <span id="val_nama"></span> / <span id="val_jenis_kelamin"></span></td>
</tr>
<tr>
<td><b>Tgl Lahir </b></td>
<td> : <span id="val_tgl_lahir"></span></td>
</tr>
<tr>
<td><b>Alamat </b></td>
<td> : <span id="val_alamat"></span></td>
</tr>
<tr>
<td><b>Tlp / Email </b></td>
<td> : <span id="val_telp"></span> / <span id="val_email"></span></td>
</tr>
</table>
<br>
<table width="80%" >
<tr>
<td><b>Asal Sekolah</b></td>
<td> : <span id="val_asal_sekolah"></span></td>
</tr>
<tr>
<td><b>Alamat Sekolah</b></td>
<td> : <span id="val_alamat_sekolah"></span></td>
</tr>
<tr>
  <td><b>Jurusan</b></td>
<td> : <span id="val_jurusan"></span></td>
</tr>
<tr>
<td><b>Minat</b></td>
<td> : <span id="val_minat"></span></td>
</tr>
<tr>
<td><b>Kompetensi Keahlian</b></td>
<td> : <span id="val_kopetensi"</></td>
</tr>
<tr>
<td><b>Lama Magang</b></td>
<td> : <span id="val_tgl_mulai"></span> s/d <span id="val_tgl_akhir"></span></td>
</tr>
</table>










              </div>
              <div class="modal-footer" >
                <div class="col-sm-8"></div>
              
              <div class="col-sm-2">
                <form action="../siswa/edit2" method="post">
                  <input type="hidden" name="id" id="val_id_siswa2">
                  <input type="hidden" name="email" id="val_email3">
                   <input type="hidden" name="nama" id="val_nama1">
                  <button type="submit" class="btn btn-danger pull-right"><i class="fa fa-close"> Tolak </i></button>
                </form>
              </div>
               <div class="col-sm-2">
                <form action="../siswa/edit1" method="post">
                  <input type="hidden" name="id" id="val_id_siswa1">
                  <input type="hidden" name="email" id="val_email2">
                  <input type="hidden" name="nama" id="val_nama2">
                  <input type="hidden" name="tgl_mulai_magang" id="val_tgl_mulai1">
                  <input type="hidden" name="tgl_akhir_magang" id="val_tgl_akhir1">
                  <input type="hidden" name="minat" id="val_minat1">

                  <!-- email -->

                  <button type="submit" class="btn btn-success pull-right"><i class="fa fa-check-square-o"> Terima </i></button>
                </form>
              </div>
               </div>



            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->


    </section>




         
    <!-- /.content -->
    <script>
    function tampildata(id, nisn, nama, jenis_kelamin, tgl_lahir, alamat, telp, email, asal_sekolah, alamat_sekolah, jurusan, minat, kopetensi_keahlian, tgl_mulai_magang, tgl_akhir_magang, foto){
      $('#val_id_siswa1').val(id);
      $('#val_id_siswa2').val(id);
      $('#val_nisn').html(nisn);
      $('#val_nama').html(nama);
      $('#val_nama1').val(nama);
      $('#val_nama2').val(nama);
      $('#val_jenis_kelamin').html(jenis_kelamin);
      $('#val_tgl_lahir').html(tgl_lahir);
      $('#val_alamat').html(alamat);
      $('#val_telp').html(telp);
      $('#val_email').html(email);
      $('#val_email2').val(email);
       $('#val_email3').val(email);
      $('#val_asal_sekolah').html(asal_sekolah);
      $('#val_alamat_sekolah').html(alamat_sekolah);
      $('#val_jurusan').html(jurusan);
      $('#val_minat').html(minat);
      $('#val_minat1').val(minat);
      $('#val_kopetensi').html(kopetensi_keahlian);
      $('#val_tgl_mulai').html(tgl_mulai_magang);
      $('#val_tgl_mulai1').val(tgl_mulai_magang);
      $('#val_tgl_akhir').html(tgl_akhir_magang);
       $('#val_tgl_akhir1').val(tgl_akhir_magang);
      $('#val_foto').attr('src', '../images/'+foto);
    }
  </script>
  <?php include "footer.php"?>